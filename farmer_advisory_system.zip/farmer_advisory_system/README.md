# 🌾 AI Farmer Advisory System

An AI-powered chatbot for farmers with NLP, crop disease image detection, and weather-based recommendations — built for rural India.

## Features
- 💬 Multilingual chatbot (Hindi, Marathi, English + voice input)
- 🌿 Crop disease detection from leaf photos (CNN model)
- 🌦️ Weather-based farming advice + pest alerts
- 📱 Mobile-first web UI

## Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/your-username/farmer-advisory-system.git
cd farmer-advisory-system

# 2. Set up environment variables
cp backend/.env.example backend/.env
# Fill in your API keys in backend/.env

# 3. Run with Docker (recommended)
docker-compose up --build

# 4. Open in browser
# Frontend: http://localhost:3000
# API docs:  http://localhost:8000/docs
```

## Manual Setup (without Docker)

```bash
# Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload

# Frontend (in a new terminal)
cd frontend
npm install
npm start
```

## Tech Stack
- **Backend:** Python, FastAPI, MongoDB
- **NLP:** HuggingFace Transformers, googletrans, langdetect
- **Vision:** TensorFlow / Keras, MobileNetV2, OpenCV
- **Weather:** OpenWeatherMap API
- **Frontend:** React.js
- **Deploy:** Docker, Railway/Render, GitHub Actions

## Train the Disease Model
Open `ml_training/train_disease_model.ipynb` in Google Colab and follow the instructions.
