from nlp.language_detector import detect_language

def test_detect_english():
    assert detect_language("my crop has yellow leaves") == "en"

def test_detect_hindi():
    lang = detect_language("मेरी फसल में बीमारी है")
    assert lang in ["hi", "mr"]
