import json, os

_path = os.path.join(os.path.dirname(__file__), "data", "responses.json")
with open(_path) as f:
    RESPONSES = json.load(f)

def generate_response(intent: str, message: str, location=None) -> str:
    return RESPONSES.get(intent,
        "I can help with crop diseases, weather, sowing, and government schemes. Please rephrase your question.")
