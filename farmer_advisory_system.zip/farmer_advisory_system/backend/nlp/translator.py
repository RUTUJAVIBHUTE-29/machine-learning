from googletrans import Translator
_t = Translator()

def translate_to_english(text: str, src: str) -> str:
    return text if src == "en" else _t.translate(text, src=src, dest="en").text

def translate_response(text: str, dest: str) -> str:
    return text if dest == "en" else _t.translate(text, src="en", dest=dest).text
