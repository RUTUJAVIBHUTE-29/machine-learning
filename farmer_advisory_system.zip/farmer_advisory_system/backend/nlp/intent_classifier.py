from transformers import pipeline
from functools import lru_cache

INTENTS = [
    "crop_disease_query", "weather_query", "sowing_advice",
    "fertilizer_advice", "market_price_query", "pest_control",
    "irrigation_advice", "government_scheme", "general_greeting"
]

@lru_cache(maxsize=1)
def load_classifier():
    return pipeline("zero-shot-classification",
                    model="facebook/bart-large-mnli", device=-1)

def classify_intent(text: str) -> tuple:
    classifier = load_classifier()
    result = classifier(text, INTENTS)
    return result["labels"][0], result["scores"][0]
