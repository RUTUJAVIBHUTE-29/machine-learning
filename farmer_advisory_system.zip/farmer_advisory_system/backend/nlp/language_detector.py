from langdetect import detect, LangDetectException

def detect_language(text: str) -> str:
    try:
        lang = detect(text)
        return lang[:2] if lang else "en"
    except LangDetectException:
        return "en"
