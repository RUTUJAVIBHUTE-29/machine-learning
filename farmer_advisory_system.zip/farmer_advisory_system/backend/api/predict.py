from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
from vision.model import predict_disease
from vision.disease_info import get_disease_info
import io

router = APIRouter()

class PredictionResponse(BaseModel):
    disease_name: str
    confidence: float
    treatment: str
    prevention: str
    severity: str

@router.post("/predict", response_model=PredictionResponse)
async def predict(file: UploadFile = File(...)):
    if file.content_type not in ["image/jpeg", "image/png", "image/jpg"]:
        raise HTTPException(status_code=400, detail="Only JPEG/PNG images supported")
    try:
        contents = await file.read()
        disease_class, confidence = predict_disease(io.BytesIO(contents))
        info = get_disease_info(disease_class)
        return PredictionResponse(
            disease_name=info["name"],
            confidence=round(confidence * 100, 2),
            treatment=info["treatment"],
            prevention=info["prevention"],
            severity=info["severity"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
