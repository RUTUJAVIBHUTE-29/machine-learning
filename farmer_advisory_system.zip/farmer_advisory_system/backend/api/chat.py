from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from nlp.intent_classifier import classify_intent
from nlp.response_generator import generate_response
from nlp.translator import translate_to_english, translate_response
from nlp.language_detector import detect_language

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    farmer_id: str | None = None
    location: str | None = None   # e.g. "Nagpur,IN"

class ChatResponse(BaseModel):
    reply: str
    intent: str
    language: str
    confidence: float

@router.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    try:
        lang = detect_language(req.message)
        english_msg = translate_to_english(req.message, lang)
        intent, confidence = classify_intent(english_msg)
        english_reply = generate_response(intent, english_msg, req.location)
        final_reply = translate_response(english_reply, lang)
        return ChatResponse(reply=final_reply, intent=intent,
                            language=lang, confidence=confidence)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
