from fastapi import APIRouter, Query, HTTPException
from weather.weather_api import fetch_current_weather, fetch_forecast
from weather.advisor import get_farming_advice

router = APIRouter()

@router.get("/weather")
async def get_weather(
    lat: float = Query(...),
    lon: float = Query(...),
    crop: str = Query("general")
):
    try:
        current = fetch_current_weather(lat, lon)
        forecast = fetch_forecast(lat, lon)
        advice = get_farming_advice(current, forecast, crop)
        return {"current": current, "forecast": forecast, "advice": advice}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
