from fastapi import APIRouter
from pydantic import BaseModel
from typing import List

router = APIRouter()

class FarmerProfile(BaseModel):
    name: str
    phone: str
    location: str
    land_area_acres: float
    crops: List[str]
    language: str = "hi"

@router.post("/farmer")
async def create_farmer(profile: FarmerProfile):
    return {"message": "Profile created", "farmer_id": "placeholder-id"}

@router.get("/farmer/{farmer_id}")
async def get_farmer(farmer_id: str):
    return {"farmer_id": farmer_id}
