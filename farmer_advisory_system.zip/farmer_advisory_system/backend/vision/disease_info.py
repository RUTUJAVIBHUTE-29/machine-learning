DISEASE_DB = {
    "Tomato__Bacterial_spot": {
        "name": "Tomato Bacterial Spot",
        "treatment": "Apply Copper Oxychloride 50WP at 2g/litre. Remove infected leaves.",
        "prevention": "Use resistant seeds. Avoid overhead irrigation. Rotate crops.",
        "severity": "Medium"
    },
    "Cotton__Leaf_curl": {
        "name": "Cotton Leaf Curl Virus",
        "treatment": "Remove and burn infected plants. Control whitefly vectors.",
        "prevention": "Plant tolerant varieties. Spray Thiamethoxam 25WG for whitefly.",
        "severity": "High"
    },
    "Healthy": {
        "name": "Healthy Plant",
        "treatment": "No treatment needed.",
        "prevention": "Continue monitoring, balanced fertilization, proper irrigation.",
        "severity": "None"
    }
}

def get_disease_info(cls: str) -> dict:
    return DISEASE_DB.get(cls, {
        "name": cls.replace("__", " – ").replace("_", " "),
        "treatment": "Consult your local Krishi Vigyan Kendra (KVK).",
        "prevention": "Practice crop rotation and use certified seeds.",
        "severity": "Unknown"
    })
