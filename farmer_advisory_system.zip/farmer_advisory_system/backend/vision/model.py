import json
import numpy as np
from PIL import Image
from functools import lru_cache
from config import settings

@lru_cache(maxsize=1)
def load_model():
    import tensorflow as tf
    model = tf.keras.models.load_model(settings.MODEL_PATH)
    with open(settings.CLASS_LABELS_PATH) as f:
        labels = json.load(f)
    return model, labels

def preprocess_image(image_bytes) -> np.ndarray:
    img = Image.open(image_bytes).convert("RGB").resize((224, 224))
    arr = np.array(img) / 255.0
    return np.expand_dims(arr, axis=0)

def predict_disease(image_bytes) -> tuple:
    model, labels = load_model()
    preds = model.predict(preprocess_image(image_bytes))
    idx = int(np.argmax(preds))
    return labels[str(idx)], float(np.max(preds))
