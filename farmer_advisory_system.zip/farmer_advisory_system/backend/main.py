from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api import chat, predict, weather, farmer
from database.connection import connect_db

app = FastAPI(title="AI Farmer Advisory System", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    await connect_db()

app.include_router(chat.router,    prefix="/api", tags=["Chat"])
app.include_router(predict.router, prefix="/api", tags=["Disease Detection"])
app.include_router(weather.router, prefix="/api", tags=["Weather"])
app.include_router(farmer.router,  prefix="/api", tags=["Farmer"])

@app.get("/")
def root():
    return {"message": "Farmer Advisory API is running"}
