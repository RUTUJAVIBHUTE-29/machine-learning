from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    MONGO_URI: str = "mongodb://localhost:27017/farmer_db"
    WEATHER_API_KEY: str = ""
    GOOGLE_TRANSLATE_KEY: str = ""
    FIREBASE_CREDENTIALS: str = ""
    JWT_SECRET: str = "change-me-in-production"
    JWT_EXPIRE_HOURS: int = 24
    MODEL_PATH: str = "vision/models/crop_disease_model.h5"
    CLASS_LABELS_PATH: str = "vision/models/class_labels.json"

    class Config:
        env_file = ".env"

settings = Settings()
