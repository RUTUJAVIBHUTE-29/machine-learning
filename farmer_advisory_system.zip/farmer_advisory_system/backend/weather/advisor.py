def get_farming_advice(current: dict, forecast: list, crop: str) -> list:
    advice = []
    temp, humidity, rain = current["temp_c"], current["humidity_pct"], current["rain_mm"]
    upcoming_rain = sum(f["rain_mm"] for f in forecast[:3])

    if upcoming_rain > 20:
        advice.append("Heavy rain expected in 24hrs. Delay fertilizer/pesticide application.")
    if humidity > 85 and temp > 28:
        advice.append("High humidity + warm temp: high fungal disease risk. Inspect crops daily.")
    if temp < 15:
        advice.append("Cold temperatures detected. Protect seedlings with mulching.")
    if rain == 0 and humidity < 40:
        advice.append("Dry conditions. Consider irrigation if soil moisture is low.")
    if crop == "cotton" and temp > 35:
        advice.append("High temp may stress cotton bolls. Irrigate in early morning.")
    if not advice:
        advice.append("Weather is favourable for farming activities today.")
    return advice
