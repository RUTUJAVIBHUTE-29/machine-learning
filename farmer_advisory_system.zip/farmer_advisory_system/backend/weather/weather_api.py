import requests
from config import settings

BASE = "https://api.openweathermap.org/data/2.5"

def fetch_current_weather(lat: float, lon: float) -> dict:
    r = requests.get(f"{BASE}/weather?lat={lat}&lon={lon}&appid={settings.WEATHER_API_KEY}&units=metric", timeout=10)
    r.raise_for_status()
    d = r.json()
    return {
        "temp_c": d["main"]["temp"],
        "humidity_pct": d["main"]["humidity"],
        "description": d["weather"][0]["description"],
        "wind_kmh": round(d["wind"]["speed"] * 3.6, 1),
        "rain_mm": d.get("rain", {}).get("1h", 0)
    }

def fetch_forecast(lat: float, lon: float) -> list:
    r = requests.get(f"{BASE}/forecast?lat={lat}&lon={lon}&appid={settings.WEATHER_API_KEY}&units=metric&cnt=7", timeout=10)
    r.raise_for_status()
    return [
        {"datetime": i["dt_txt"], "temp_c": i["main"]["temp"],
         "humidity_pct": i["main"]["humidity"], "rain_mm": i.get("rain", {}).get("3h", 0)}
        for i in r.json()["list"]
    ]
