import motor.motor_asyncio
from config import settings

client = None
db = None

async def connect_db():
    global client, db
    client = motor.motor_asyncio.AsyncIOMotorClient(settings.MONGO_URI)
    db = client.get_default_database()
    print("✅ Connected to MongoDB")

def get_db():
    return db
