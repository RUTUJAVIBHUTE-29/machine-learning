# AI Farmer Advisory System – Project Structure

```
farmer-advisory-system/
│
├── backend/                          # Python FastAPI backend
│   ├── main.py                       # App entry point, route registration
│   ├── config.py                     # Environment variables, settings
│   ├── requirements.txt              # All Python dependencies
│   ├── .env                          # API keys (never commit this!)
│   │
│   ├── api/                          # API route handlers
│   │   ├── __init__.py
│   │   ├── chat.py                   # POST /api/chat  – NLP chatbot endpoint
│   │   ├── predict.py                # POST /api/predict – image disease detection
│   │   ├── weather.py                # GET  /api/weather – weather + advice
│   │   └── farmer.py                 # CRUD /api/farmer – farmer profile
│   │
│   ├── nlp/                          # NLP Chatbot module
│   │   ├── __init__.py
│   │   ├── intent_classifier.py      # HuggingFace intent detection model
│   │   ├── response_generator.py     # Rule-based + LLM response logic
│   │   ├── language_detector.py      # Detect Hindi/Marathi/English
│   │   ├── translator.py             # Translate query → English → translate back
│   │   ├── voice_handler.py          # Speech-to-text (SpeechRecognition lib)
│   │   └── data/
│   │       ├── intents.json          # Training intent labels and patterns
│   │       └── responses.json        # Predefined responses per intent
│   │
│   ├── vision/                       # Image Processing / Disease Detection
│   │   ├── __init__.py
│   │   ├── model.py                  # Load and run MobileNetV2 / ResNet50
│   │   ├── preprocess.py             # Resize, normalize, augment images
│   │   ├── disease_info.py           # Disease name → treatment text mapping
│   │   ├── train.py                  # Training script (run on Colab)
│   │   └── models/
│   │       ├── crop_disease_model.h5 # Trained Keras model weights
│   │       └── class_labels.json     # Index → disease name mapping
│   │
│   ├── weather/                      # Weather-Based Recommendation Engine
│   │   ├── __init__.py
│   │   ├── weather_api.py            # Fetch OpenWeatherMap current + forecast
│   │   ├── advisor.py                # Weather conditions → crop advice rules
│   │   ├── sowing_calendar.py        # Crop × season × location → sow window
│   │   ├── pest_alert.py             # Humidity + temp → pest outbreak risk
│   │   └── data/
│   │       └── crop_weather_rules.json  # Rule config (JSON, easy to edit)
│   │
│   ├── models/                       # Database models (ORM schemas)
│   │   ├── __init__.py
│   │   ├── farmer.py                 # Farmer profile schema
│   │   ├── query_log.py              # Log of all farmer queries + responses
│   │   └── prediction_log.py         # Image predictions history
│   │
│   ├── database/                     # DB connection & helpers
│   │   ├── __init__.py
│   │   ├── connection.py             # MongoDB / PostgreSQL connection setup
│   │   └── seed_data.py              # Seed crop/disease/rule data
│   │
│   ├── utils/                        # Shared utilities
│   │   ├── __init__.py
│   │   ├── auth.py                   # JWT token generation / verification
│   │   ├── notifications.py          # Firebase FCM push notification sender
│   │   ├── image_utils.py            # Base64 encode/decode, file validation
│   │   └── logger.py                 # Structured logging setup
│   │
│   └── tests/                        # Unit & integration tests
│       ├── test_nlp.py
│       ├── test_vision.py
│       ├── test_weather.py
│       └── test_api.py
│
├── frontend/                         # React.js Web App
│   ├── public/
│   │   ├── index.html
│   │   └── favicon.ico
│   ├── src/
│   │   ├── App.jsx                   # Root component, routing
│   │   ├── index.js
│   │   │
│   │   ├── pages/
│   │   │   ├── Home.jsx              # Landing / login page
│   │   │   ├── Chat.jsx              # Main chatbot interface
│   │   │   ├── Weather.jsx           # Weather dashboard + forecast
│   │   │   ├── Profile.jsx           # Farmer profile setup
│   │   │   └── History.jsx           # Past queries and advice
│   │   │
│   │   ├── components/
│   │   │   ├── ChatBubble.jsx        # Individual message bubble
│   │   │   ├── ImageUpload.jsx       # Drag-drop / camera image input
│   │   │   ├── VoiceInput.jsx        # Mic button for speech input
│   │   │   ├── WeatherCard.jsx       # Current weather display card
│   │   │   ├── DiseaseResult.jsx     # Disease name + treatment card
│   │   │   ├── ForecastChart.jsx     # 7-day rainfall/temp chart
│   │   │   └── Navbar.jsx
│   │   │
│   │   ├── services/
│   │   │   ├── api.js                # Axios instance + base URL config
│   │   │   ├── chatService.js        # Call /api/chat
│   │   │   ├── weatherService.js     # Call /api/weather
│   │   │   └── predictionService.js  # Call /api/predict with image
│   │   │
│   │   ├── context/
│   │   │   ├── AuthContext.jsx       # JWT auth state
│   │   │   └── FarmerContext.jsx     # Farmer profile global state
│   │   │
│   │   └── assets/
│   │       ├── crop-icons/           # PNG icons per crop type
│   │       └── disease-images/       # Sample reference images
│   │
│   ├── package.json
│   └── .env                          # REACT_APP_API_URL=http://...
│
├── ml_training/                      # Standalone training notebooks
│   ├── train_disease_model.ipynb     # Google Colab notebook (run here)
│   ├── intent_training.ipynb         # Fine-tune NLP intent classifier
│   ├── dataset_prep.py               # Download + organize PlantVillage
│   └── evaluate_model.py             # Print accuracy, confusion matrix
│
├── docker/                           # Docker configuration
│   ├── Dockerfile.backend            # Python FastAPI container
│   ├── Dockerfile.frontend           # React production build container
│   └── nginx.conf                    # Reverse proxy config
│
├── docker-compose.yml                # Run full stack locally
├── .github/
│   └── workflows/
│       └── deploy.yml                # GitHub Actions CI/CD pipeline
│
├── docs/
│   ├── API.md                        # Swagger/OpenAPI endpoint docs
│   ├── SETUP.md                      # How to run locally
│   └── architecture_diagram.png
│
├── .gitignore
└── README.md
```

---

## Key Files – Quick Reference

| File | Purpose |
|------|---------|
| `backend/main.py` | FastAPI app startup |
| `backend/nlp/intent_classifier.py` | HuggingFace model for chat |
| `backend/vision/model.py` | Crop disease CNN inference |
| `backend/weather/advisor.py` | Weather → farming advice |
| `backend/.env` | API keys (OpenWeatherMap, Google Translate, Firebase) |
| `frontend/src/pages/Chat.jsx` | Main farmer-facing chat UI |
| `ml_training/train_disease_model.ipynb` | Train on Google Colab |
| `docker-compose.yml` | One command to run everything |
